import React, {useState} from 'react';
import './App.css';
import TodoList, {TaskType} from "./TodoList";
import {v1} from "uuid";

//data -> CRUD
//create +
//read (+,+,+)// filter => //sort, pagination
//update +
//delete +

//CLI
//GUI-!!!!!!
//VUI

export type FilterValuesType = "all" | "active" | "completed"



function App() {
    // BLL:
   const todoListTitle: string = "What to learn"
    const [tasks, setTasks] = useState<Array<TaskType>>([
        {id: v1(), title: "HTML&CSS" , isDone: true},
        {id: v1(), title: "JS/TS" , isDone: true},
        {id: v1(), title: "React" , isDone: false},
        {id: v1(),  title: "Redux" , isDone: false},
        {id: v1(),  title: "RTK" , isDone: false},
    ])
    // console.log(tasks)
    const [filter, setFilter] = useState<FilterValuesType>("all")


    console.log(v1())
    const removeTask = (taskId: string) => {
        setTasks(tasks.filter((t) => t.id !== taskId))
        console.log(tasks)
    }
    const addTask = (title: string)=> {
        const newTask: TaskType = {
            id: v1(),
            title: title,
            isDone: false
        }
        setTasks([newTask, ...tasks])
    }
    const changeTaskStatus = (taskId: string, newTaskStatus: boolean) => {
       const updatedTasks: Array<TaskType> = tasks.map(t => t.id === taskId ? {...t , isDone: newTaskStatus} : t)
        setTasks(updatedTasks)
    }

    const changeFilter = (filter: FilterValuesType) => {
        setFilter(filter)
    }

    //GUI:
    const getFilteredTasks = (t: Array<TaskType>, f: FilterValuesType) => {
        let tasksForTodoList = t;
        if(f === "active"){
            tasksForTodoList = t.filter(t => !t.isDone)
        }
        if(f === "completed"){
            tasksForTodoList = t.filter(t => t.isDone)
        }
        return tasksForTodoList
    }



    return (
        <div className="App">
            <TodoList
                tasks={getFilteredTasks(tasks, filter)}
                title={todoListTitle}
                filter={filter}
                removeTask={removeTask}
                changeFilter={changeFilter}
                addTask={addTask}
                changeTaskStatus={changeTaskStatus}
            />
        </div>
    );
}

export default App;
